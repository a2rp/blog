export const meta = {
    title: "What Really Happens When You Type a Web Address and Press Enter?",
    slug: "what-happens-when-you-type-a-web-address",
    date: "2025-01-07",
    author: "Ashish Ranjan — Full-Stack Developer",
    category: "How The Internet Works",
    tags: ["DNS", "TLS/SSL", "HTTP", "Browser", "Servers", "Networking"],
    excerpt:
        "A restaurant-style tour of DNS lookups, TLS handshakes, HTTP requests, servers, and the browser render pipeline—what really happens after you hit Enter.",
    cover: null, // no images
};

export default function Post() {
    return (
        <article>
            <p>
                You've done it thousands of times. You open your laptop, type
                <code> google.com</code> or <code> netflix.com</code> into the address
                bar, and press Enter. A second later, a webpage appears.
            </p>
            <p>
                It feels like magic, but it's not. It's a breathtakingly complex
                symphony of machines talking to each other, all in the blink of an eye.
                As a full-stack developer who has built these systems for over a decade,
                I still find this process beautiful.
            </p>
            <p>Let&apos;s demystify the magic—think of it like ordering food at a restaurant.</p>

            <h2>1) You Tell the Browser Where You Want to Go (Placing Your Order)</h2>
            <p>
                You type the URL and hit Enter. Your browser (Chrome, Safari, etc.) is
                your assistant with a mission: “Get me the website for that domain.”
            </p>

            <h2>2) Finding the Secret Address: The DNS Lookup (Asking for Directions)</h2>
            <p>
                The internet runs on IP addresses (e.g., <code>142.251.42.206</code>),
                not names like <code>google.com</code>. Your browser first checks its
                cache, then your OS, then asks your ISP's DNS resolver to translate the
                name into an IP address—the internet's phonebook.
            </p>
            <p>
                <em>Analogy:</em> You want “Tony's Pizza” but don't know the address, so
                you look it up and find “123 Main Street.”
            </p>

            <h2>3) Making a Secure Connection: The SSL/TLS Handshake (Knocking on the Door)</h2>
            <p>
                With the IP in hand, the browser connects and performs a TLS handshake,
                exchanging keys and verifying certificates. If all is well, you see the
                padlock (🔒) and you now have a private, encrypted tunnel.
            </p>
            <p>
                <em>Analogy:</em> A bouncer checks IDs and sets up a private hallway so
                nobody can eavesdrop.
            </p>

            <h2>4) Making the Request: The HTTP Request (Ordering Your Food)</h2>
            <p>
                Over the secure connection, the browser sends a structured HTTP request:
                “Please give me the homepage.” It includes headers about the browser,
                languages, cookies, etc.
            </p>
            <p>
                <em>Analogy:</em> You tell the waiter: “One margherita pizza and a soda.”
            </p>

            <h2>5) The Server Prepares Your Page (The Kitchen Gets Cooking)</h2>
            <p>
                A server (powerful computer in a data center) receives the order. It may
                query databases, call services, and run code to generate a personalized
                response.
            </p>
            <p>
                <em>Analogy:</em> The kitchen grabs ingredients (data), cooks (processes),
                and plates your dish (the response).
            </p>

            <h2>6) The Response is Delivered (Your Food is Served)</h2>
            <p>
                The server returns HTML (content &amp; structure), CSS (design), and
                JavaScript (interactivity).
            </p>
            <ul>
                <li><strong>HTML</strong>: the skeleton/content</li>
                <li><strong>CSS</strong>: the styling/ layout</li>
                <li><strong>JavaScript</strong>: dynamic/interactive behavior</li>
            </ul>

            <h2>7) The Browser's Final Touch (You Eat the Food)</h2>
            <p>
                The browser parses HTML, applies CSS, runs JavaScript, builds the DOM,
                and paints the page. You see content appear, images pop in, and features
                become interactive.
            </p>
            <p>
                <em>Analogy:</em> You finally eat and enjoy the meal.
            </p>

            <p>
                And all of this—DNS to render—often happens in under a second. The next
                time you press Enter, appreciate the technological symphony you just
                conducted. It's anything but magic.
            </p>
        </article>
    );
}
